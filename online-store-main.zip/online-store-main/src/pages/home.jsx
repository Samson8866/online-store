

import "./styles/home.css";

function Home(){
    return(
        <div className="home page">
            <h1>Samson's Online Store</h1>
        </div>
    );
}

export default Home;