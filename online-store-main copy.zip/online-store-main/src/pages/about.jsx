import "./styles/about.css";

function About(){
    return(
        <div className="about page">
            <h1>About Us</h1>
            <h3>Samsontherealtor@gmail.com</h3>
        </div>
    );
}

export default About;