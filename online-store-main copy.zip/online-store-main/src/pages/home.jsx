

import "./styles/home.css";

function Home(){
    return(
        <div className="home page">
            <h1>Stay Fresh Apparel</h1>
        </div>
    );
}

export default Home;