import "./styles/footer.css";

function Footer(){
    return(
        <div className="footer">
            <p>Online Store created by Samson Hill</p>
        </div>
    );
}

export default Footer;